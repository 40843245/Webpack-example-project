# reference
## guide reference
+ About get started with `Development in WebPack`, see `Development Chapter in WebPack`[^1].

+ About `mode: 'development'` field in `webpack.config.js` configuration file, see `mode in Webpack configuration`[^2]. 

[^1]: [Development Chapter in WebPack`](https://webpack.js.org/guides/development/)

[^2]: [`mode in Webpack configuration`](https://webpack.js.org/configuration/mode/)