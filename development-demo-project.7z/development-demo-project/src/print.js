export default function printMe() {
    cosnole.log('I get called from print.js!');
}