# reference
## guide reference
About `Authoring Libraries in Webpack`, see `Authoring Libraries Chapter in Webpack`[^1].

[^1]: [`Authoring Libraries Chapter in Webpack`](https://webpack.js.org/guides/author-libraries/)