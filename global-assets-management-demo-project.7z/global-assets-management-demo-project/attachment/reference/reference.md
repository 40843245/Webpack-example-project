# reference
## guide reference
+ About get started with `WebPack`, see `quickstart guide in WebPack`[^1] and `quiuckstart guide.md of my notes of Webpack (Github)`[^2]

+ About `mode: 'development'` field in `webpack.config.js` configuration file, see `mode in Webpack configuration`[^3]. 

[^1]: [`quickstart guide in WebPack`](https://webpack.js.org/guides/getting-started)

[^2]: [`quiuckstart guide.md of my notes of Webpack (Github)`]()

[^3]: [`mode in Webpack configuration`](https://webpack.js.org/configuration/mode/)