# NOTICE
> [!TIP]
> This guide extends on code examples found in the [Output Management](https://webpack.js.org/guides/output-management) guide.

> [!WARNING]
> The tools in this guide are only meant for development, please avoid using them in production!